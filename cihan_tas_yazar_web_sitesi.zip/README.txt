# Cihan TAŞ | Yazar Web Sitesi

Bu klasör, mobil uyumlu tek sayfalık ilk site sürümüdür.

## Yayına almak
1. `index.html` dosyasını hosting alanına yükleyin.
2. Alan adınızı hosting hesabına bağlayın.
3. Kitap kapaklarını ve sosyal medya bağlantılarını `index.html` içinden güncelleyin.

## Sonraki geliştirmeler
- Gerçek kitap kapaklarının eklenmesi
- Her kitap için ayrı detay sayfası
- Online satış / ödeme
- Yönetim paneli
- İletişim formu
- SEO ve Google Search Console
